Basic dns spoofer.
This will likely not work with most large websites which require good security, such as banks and
apparently search engines(Google, Bing)
To report bugs please contact me at persianperson10#4070 on discord or by email at
britishperson10@protonmail.com
	
	-Joe
